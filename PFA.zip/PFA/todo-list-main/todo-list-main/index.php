<?php

echo "<a href='http://localhost/PFA/acceuil%20page/index.php' style='text-decoration: none; color: #6c5ce7; font-size: 15px; margin: 10px;'>
    <b style='font-size: 30px;'>↰</b> 
    <b style='border-right:2px solid black; border-bottom:2px solid black;'>
        Revenir à l'accueil.
    </b>
</a>";

?>

<!DOCTYPE html>
<html lang="en" data-theme="night">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- CSS -->
    <link rel="stylesheet" href="css/style.css">

    <!--- Tailwind CSS & Daisy UI CSS -->
    <link href="https://cdn.jsdelivr.net/npm/daisyui@2.18.0/dist/full.css" rel="stylesheet" type="text/css" />
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2/dist/tailwind.min.css" rel="stylesheet" type="text/css" />
    <link href='https://unpkg.com/boxicons@2.1.2/css/boxicons.min.css' rel='stylesheet'>

    <!-- Favicon -->
    <link rel="icon" type="image/svg+xml" href="res/favicon.ico">

    <title>TO-DOIT</title>
</head>
<body>

    <!-- Copyright -->
    <footer>
        <div class="author-text">
            <p>Made with ❤️ by <a href="https://github.com/abdellatif-laghjaj" target="_blank"><b>Abdellatif Laghjaj</b></a></p>
        </div>
    </footer>
    
    <div class="container">
        <header>
            <h1>Todo List</h1>
            <!-- Error message -->
            <div class="alert-message"></div>
            <div class="input-section">
                <input type="text" placeholder="Add a todo . . ." class="input input-bordered input-secondary w-full max-w-xs" />
                <input type="date" class="input input-bordered input-secondary w-full max-w-xs schedule-date" />
                <button class="btn btn-secondary add-task-button">
                    <i class="bx bx-plus bx-sm"></i>
                </button>
            </div>
        </header>

        <div class="todos-filter">
            <div class="dropdown">
                <label tabindex="0" class="btn m-1">Filter</label>
                <ul tabindex="0" class="dropdown-content menu p-2 shadow bg-base-100 rounded-box w-52">
                    <li onclick="filterTodos('all')"><a>All</a></li>
                    <li onclick="filterTodos('pending')"><a>Pending</a></li>
                    <li onclick="filterTodos('completed')"><a>Completed</a></li>
                </ul>
            </div>
            <button class="btn btn-secondary delete-all-btn">
                Delete All
            </button>
        </div>

         <table class="table w-full">
            <thead>
                <tr>
                    <th>Task</th>
                    <th>Due Date</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody class="todos-list-body">
            </tbody>
        </table>

    </div>

    <!--Theme switcher-->
    <div class="theme-switcher">
        <div  style="margin-left: -1270px;">
            <a href="http://localhost/PFA/acceuil%20page/index.php" style="text-decoration: none; color: #6c5ce7; font-size: 15px;">
                <b style="font-size: 30px;">↰</b> 
                <b style="border-right:2px solid black; border-bottom:2px solid black;font-size: 15px;">
                    Revenir à l'accueil.
                </b>
            </a>
        </div>
    
        <div class="dropdown dropdown-left">
            <label tabindex="0" class="btn m-1">
                <i class='bx bxs-palette bx-sm'></i>
            </label>
            <ul tabindex="0" class="dropdown-content menu p-2 shadow bg-base-100 rounded-box w-52">
                <li class="theme-item" theme="cupcake"><a>cupcake</a></li>
                <li class="theme-item" theme="dark"><a>dark</a></li>
                <li class="theme-item" theme="light"><a>light</a></li>
                <li class="theme-item" theme="bumblebee"><a>bumblebee</a></li>
                <li class="theme-item" theme="synthwave"><a>synthwave</a></li>
                <li class="theme-item" theme="halloween"><a>halloween</a></li>
                <li class="theme-item" theme="fantasy"><a>fantasy</a></li>
                <li class="theme-item" theme="dracula"><a>dracula</a></li>
                <li class="theme-item" theme="aqua"><a>aqua</a></li>
                <li class="theme-item" theme="luxury"><a>luxury</a></li>
                <li class="theme-item" theme="night"><a>night</a></li>
            </ul>
        </div>
    </div>

    <!-- JS -->
    <script src="js/main.js"></script>

</body>
</html>
