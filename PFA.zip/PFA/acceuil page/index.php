
<?php

    //sleep(1);

?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8"/>
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>GTDToDoList</title>
        <!-- Favicon-->
        <link rel="icon" type="image/x-icon" href="icon list.png" />
        <!-- Core theme CSS (includes Bootstrap)-->
        <link href="css/styles.css" rel="stylesheet"/>

        <link href="style.css" rel="stylesheet"/>

        <!-- css for get started-->
        

        <!-- Css for Contact us -->
        <link rel="stylesheet" href="contact_us.css">

        <!-- Css for Footer -->
        <link rel="stylesheet" href="footer.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.min.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">
        
        <style>

            

        </style>
    </head>
    <body>
        <div class="d-flex" id="wrapper">
            <!-- Sidebar-->
            <div class="border-end bg-white" id="sidebar-wrapper">
                <div class="sidebar-heading border-bottom bg-light" style="color:rgb(206, 35, 35);"><b>GTDToDoList</b></div>
                <div class="list-group list-group-flush">
                    <a class="list-group-item list-group-item-action list-group-item-light p-3" href="index.php">Page accueil</a>
                    <a class="list-group-item list-group-item-action list-group-item-light p-3" href="http://localhost/PFA/todo-list-main/todo-list-main/index.php">Ajouter des taches</a>
                    <a class="list-group-item list-group-item-action list-group-item-light p-3" href="#!">Mon journal</a>
                    <a class="list-group-item list-group-item-action list-group-item-light p-3" href="#!">Evenements</a>
                    <!--<a class="list-group-item list-group-item-action list-group-item-light p-3" href="#!">Profile</a>-->
                    <a class="list-group-item list-group-item-action list-group-item-light p-3" href="#!">Status</a>
                </div>
            </div>
            <!-- Page content wrapper-->
            <div id="page-content-wrapper">
                <!-- Top navigation-->
                <nav class="navbar navbar-expand-lg navbar-light bg-light border-bottom">
                    <div class="container-fluid">
                        <button class="btn btn-primary" id="sidebarToggle">Menu</button>
                        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"><span class="navbar-toggler-icon"></span></button>
                        <div class="collapse navbar-collapse" id="navbarSupportedContent">
                            <ul class="navbar-nav ms-auto mt-2 mt-lg-0">
                                <li class="nav-item active"><a class="nav-link" href="index.php"><b>Accueil</b> <img style="width: 20px;" src="icon home.png" alt=""></a></li>
                                <li style='margin-right: 30px;' class="nav-item active"><a class="nav-link" href="#!"><b>Notification</b> <img style="width: 20px;" src="icon notification.png" alt=""></a></li>
                               <!-- <li class="nav-item"><a class="nav-link" href="http://localhost/PFA/login_logup/creer_compte.php"><b>Authentification</b> <img style="width: 20px;" src="icon profile.png" alt=""></a></li>-->
                                    
                                    <?php   
                                        //session_start();
                                        if (!isset($_SESSION['nom'])) {
                                            echo "<script>alert('vous n'étes pas connecté')</script>";
                                            echo "<li class='nav-item active'>
                                                        <a href='http://localhost/PFA/login_logup/seconnecter.php' class='nav-link'>
                                                            <b>Authentification</b>
                                                            <img style='width: 20px;' src='icon profile.png' alt=''>
                                                        </a>
                                                </li>";
                                        } 
                                        else {
                                            echo "<li class='nav-item active'>
                                                    <a href='http://localhost/PFA/login_logup/deconnexion.php' class='nav-link' style='display: flex; align-items: center;'>
                                                        <b style='margin-right: 5px; color: green; border: 3px solid #41B06E; border-radius: 10px; padding: 2px;'>BONJOUR ".$_SESSION['nom']."</b>
                                                        <img style='width: 25px; height: 25px; margin-right: 30px;' src='cercle vert.png' alt=''>
                                                        <b>Déconnexion</b>
                                                        <img style='width: 20px; margin-left: 5px;' src='icon off.png' alt=''>
                                                    </a>
                                                </li>";
                                        }
                                    ?>
                                <li class="nav-item dropdown">
                                    <!--
                                    <a class="nav-link dropdown-toggle" id="navbarDropdown" href="#" role="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Dropdown</a>
                                    <div class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                                        <a class="dropdown-item" href="#!">Action</a>
                                        <a class="dropdown-item" href="#!">Another action</a>
                                        <div class="dropdown-divider"></div>
                                        <a class="dropdown-item" href="#!">Something else here</a>
                                    </div>
                                    -->
                                </li>
                            </ul>
                        </div>
                    </div>
                </nav>
                <!-- Page content-->
                    <div class="container-fluid">
                        <h1 class="mt-4">Bienvenue sur <b style="color: rgb(206, 35, 35);">GTDToDoList</b></h1>
                        <br>
                        <p>GTDToDoList, est un outil essentiel pour gérer efficacement son temps et ses responsabilités. Que ce soit pour des projets professionnels, des tâches ménagères ou des objectifs personnels, une todolist permet de compiler et de prioriser les différentes activités à réaliser. Elle offre une vue d'ensemble des tâches à accomplir, permettant ainsi de planifier son emploi du temps de manière stratégique et de suivre ses progrès au fil du temps. En somme, une todolist est un allié précieux pour rester organisé et productif au quotidien</p>
                        
                        <!--
                            <p>The starting state of the menu will appear collapsed on smaller screens, and will appear non-collapsed on larger screens. When toggled using the button below, the menu will change.</p>
                            <p>
                                Make sure to keep all page content within the
                                <code>#page-content-wrapper</code>
                                . The top navbar is optional, and just for demonstration. Just create an element with the
                                <code>#sidebarToggle</code>
                                ID which will toggle the menu when clicked.
                            </p>
                        -->

                        <br>
                        <br>
                        <br>
                        <br>
                        <br>
                        <br>
                        <br>
                        <br>
                        <br>
                        <br>

                        <?php

                            include("get started/get_started.php");

                        ?>
                        
                            
                    
                </div>
            </div>
        </div>
        
        <!-- Bootstrap core JS-->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
        <!-- Core theme JS-->
        <script src="js/scripts.js"></script>


        <!-- Zone texte -->

        <?php

            //include("C:\wamp\www\PFA\acceuil page\zone texte\index.html");
        ?>

        
        <!-- Our service -->
        <?php

            include("C:\wamp\www\PFA\acceuil page\Our Services\our_service.html");
        ?>

         
    <!-- CONTACT US -->

    <div class="container_contact">
  <div class="left-section">
    <img src="photo_contact_us_2.png" alt="photo_contact_us" />
  </div>
  <div class="right-section">
    <h2 style="text-align:center; font-family:arial black;">Contacter nous ici !</h2>
    <form>
      <input name="name" type="text" class="feedback-input" placeholder="Name" />
      <input name="email" type="text" class="feedback-input" placeholder="Email" />
      <textarea name="text" class="feedback-input" placeholder="Comment"></textarea>
      <input class="bouton" type="submit" value="SUBMIT" />
    </form>
  </div>
</div>



    <!-- FOOTER -->

    <div class="footer-clean">
        <footer>
            <div class="container">
                <div class="row justify-content-center">
                <div class="col-sm-4 col-md-3 item">
                        <h3>GTDToDoList</h3>
                            <img src="photo_contact_us.jpg" style="width: 60px;height: 60px;" alt="photo_contact_us" />
                    </div>
                    <div class="col-sm-4 col-md-3 item">
                        <h3>Services</h3>
                        <ul>
                            <li><a href="#">Gestion des taches</a></li>
                            <li><a href="#">Journal des notes</a></li>
                            <li><a href="#">Evenement</a></li>
                            <li><a href="#">Statut</a></li>
                        </ul>
                    </div>
                    <div class="col-sm-4 col-md-3 item">
                        <h3>A propos</h3>
                        <ul>
                            <li><a href="#">Blog</a></li>
                            <li><a href="#">Comment utiliser</a></li>
                            <li><a href="#">Contact</a></li>
                        </ul>
                    </div>
                    <div class="col-lg-3 item social">
                            <a href="#"><i class="icon ion-social-facebook"></i></a>
                            <a href="#"><i class="icon ion-social-twitter"></i></a>
                            <a href="#"><i class="icon ion-social-instagram"></i></a>
                            <a href="#"><i class="icon ion-social-linkedin"></i></a>
                            
                        <p class="copyright">Company Name © 2018</p>
                    </div>
                </div>
            </div>
        </footer>
    </div>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/js/bootstrap.bundle.min.js"></script>

<!-- Credit to https://epicbootstrap.com/snippets/footer-with-columns -->



    </body>
</html>
