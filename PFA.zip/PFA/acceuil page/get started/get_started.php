<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>

    <link href="style_for_get_started.css" rel="stylesheet">
</head>
<body>
    



<b>
    <p style="text-align:center;">
        Ready to boost your productivity? Sign up now and start managing your tasks efficiently. Whether you're a student, professional, or busy parent, our smart to-do list app has you covered!
    </p>
</b>
    <div class="buttons-container">
                        
        <button class="button-arounder">GET STARTED</button>
                        
    </div>

</body>
</html>