

  CREATE TABLE IF NOT EXISTS 'utilisateur' (
                            'id' int(11) NOT NULL,
                            'nom' varchar(255) NOT NULL,
                            'prenom' varchar(255) NOT NULL,
                            'email' varchar(255) NOT NULL,
                            'tel' varchar(255) NOT NULL,
                            'pass' varchar(255) NOT NULL
                          );


  ALTER TABLE `utilisateur`
    ADD PRIMARY KEY (`id`);

 
  ALTER TABLE `utilisateur`
    MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
  COMMIT;

 