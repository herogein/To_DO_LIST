<?php 

 	sleep(1.5);

include "connection_a_database.php";

session_start();

error_reporting(0);

/* 
	if (isset($_SESSION['nom'])) {

		header("Location: http://localhost/PFA/acceuil%20page/index.php");

	}
*/
	if (isset($_POST['submit'])) {
		$email1 = $_POST['email'];
		$pass1 = md5($_POST['pass']);
	
		// Hash the input password using MD5
		//$hashed_pass = md5($pass);
	
		// Fetch user data from the database
		$sql = "SELECT * FROM utilisateur WHERE email = '$email' AND pass = '$pass'";
		$result = mysqli_query($conn, $sql);
	
		if ($email1 == $_SESSION['email'] && $pass1 == $_SESSION['pass']) {
			header("Location: http://localhost/PFA/acceuil%20page/index.php");
		

		/* 
		if ($result && $result->num_rows > 0) {
			$row = mysqli_fetch_assoc($result);
			$_SESSION['nom'] = $row['nom'];
			$_SESSION['email'] = $row['email'];
	
			header("Location: http://localhost/PFA/acceuil%20page/index.php");
			exit(); // Ensure script execution stops after redirection
		*/
		} else {
			echo "<script>alert('Email ou mot de passe est incorrect.')</script>";
		}
	}
	
/*
	if (isset($_POST['submit'])) {

		$email 	= $_POST['email'];
		$pass 	= $_POST['pass'];
		
		$known_hash = md5($pass);

		$sql = "SELECT * FROM utilisateur WHERE pass = '$pass'";

			if ($sql === $known_hash) {
				echo "<script>alert(' matched')</script>";
			} 


		$sql 	= "SELECT * FROM utilisateur WHERE email = '$email' AND pass = '$pass'";
		$result = mysqli_query($conn, $sql);

		if ($result -> num_rows > 0) {

			$row = mysqli_fetch_assoc($result);
			$_SESSION['nom'] 	= $row['nom'];
			//$_SESSION['prenom'] = $row['prenom'];
			$_SESSION['email'] 	= $row['email'];

			header("Location: http://localhost/PFA/acceuil%20page/index.php");
		} 
		else {
			echo "<script>alert(' Email ou mot de passe est incorrect.')</script>";
		}
	}

*/
?>

<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">


		<link href="style.css" rel="stylesheet">

		<title>Log in</title>
	</head>

<body>

	<div class="container">

		<a href="http://localhost/PFA/acceuil%20page/index.php" style="text-decoration: none; color: #6c5ce7; font-size: 15px;"><b style="font-size: 30px;">↰</b> <b style="border-right:2px solid black; border-bottom:2px solid black;">Revenir à l'accueil.</b></a>

		<form action="" method="POST" class="login-email">

			<p class="login-text" style="font-size: 2rem; font-weight: 800;">Connexion</p>

			<div class="input-group">
				<input type="email" placeholder="Votre mail" name="email" value="<?php echo $email; ?>" required>
			</div>

			<div class="input-group">
				<input type="password" placeholder="Votre mot de passe" name="pass" value="<?php echo $_POST['pass']; ?>" required>
			</div>

			<div class="input-group">
				<button name="submit" class="btn">Connexion</button>
			</div>
			
			<p class="login-register-text">Vous n'avez pas un compte ? 
				<br>
			<a style="margin-left: 30px;" href="creer_compte.php">Creer un compte ici !</a></p>

		</form>

	</div>

</body>
</html>
