<?php 


    $server = "localhost";
    $user = "root";
    $pass = "";
    $database = "todolist";

    $conn = mysqli_connect($server, $user, $pass, $database);

    if (!$conn) {
        die("<script>alert('Connection echouez.')</script>");
    }

    // creer une base de donnée
    $base_name = "CREATE DATABASE todolist";
    
    // verifier la creation de la base de donnée
        if (mysqli_query($conn,$base_name)) 
            {echo "base de donnée crée en succés";}
        else 
            {"Erreur lors de la création de la BD : ".mysqli_error($conn);}


?>