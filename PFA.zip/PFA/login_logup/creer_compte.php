<?php 

sleep(1.5);

include "connection_a_database.php";

error_reporting(0);

session_start();

/* 
	if (isset($_SESSION['nom'])) {

		header("Location: seconnecter.php");
	}
*/
	if (isset($_POST['submit'])) {

		$nom 		= $_POST['nom'];
		$prenom 	= $_POST['prenom'];
		$email 		= $_POST['email'];
		$tel 		= $_POST['tel'];
		$pass 		= md5($_POST['pass']);
		$cpass 		= md5($_POST['cpass']);

		$_SESSION['nom'] = $nom;
		$_SESSION['email'] = $email;
		$_SESSION['pass'] = $pass;

		if ($pass == $cpass) {

			$sql 	= "SELECT * FROM utilisateur WHERE email='$email'";
			$result = mysqli_query($conn, $sql);

			if (!$result -> num_rows > 0) {

				$sql = "INSERT INTO utilisateur (nom, prenom, email, tel, pass)
						VALUES ('$nom' , '$prenom' , '$email' , '$tel' , '$pass')";
				$result = mysqli_query($conn, $sql);

				if ($result) {

					echo "<script>alert('Enregistrement de l'utilisateur terminé.')</script>";

					$nom 			= "";
					$prenom 		= "";
					$email 			= "";
					$tel 			= "";
					$_POST['pass'] 	= "";
					$_POST['cpass'] = "";
				} 
				else {
					echo "<script>alert(' Quelque chose est incorrect. ')</script>";
				}
			} 
			else {
				echo "<script>alert(' l'email existe déja. ')</script>";
			}
			
		} 
		else {
			echo "<script>alert('Le mot de passe ne correspond pas.')</script>";
		}
	}

?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

	<link rel="stylesheet" type="text/css" href="style.css">

	<title>Inscription</title>
</head>

<body>

	<div class="container">

		<a href="http://localhost/PFA/acceuil%20page/index.php" style="text-decoration: none; color: #6c5ce7; font-size: 15px;"><b style="font-size: 30px;">↰</b> <b style="border-right:2px solid black; border-bottom:2px solid black;">Revenir à l'accueil.</b></a>
		
		<form action="" method="POST" class="login-email">

            <p class="login-text" style="font-size: 2rem; font-weight: 800;">Inscription</p>
			
			<div class="input-group">
				<input type="text" placeholder="votre nom" name="nom" value="<?php echo $nom; ?>" required>
			</div>

			<div class="input-group">
				<input type="text" placeholder="votre prenom" name="prenom" value="<?php echo $prenom; ?>" required>
			</div>

			<div class="input-group">
				<input type="email" placeholder="votre mail" name="email" value="<?php echo $email; ?>" required>
			</div>

			<div class="input-group">
				<input type="text" placeholder="votre numero whatsapp" name="tel" value="<?php echo $tel; ?>" required>
			</div>

			<div class="input-group">
				<input type="password" placeholder="un mot de passe" name="pass" minlenght="8" value="<?php echo $_POST['pass']; ?>" required>
            </div>

            <div class="input-group">
				<input type="password" placeholder="Confirmer le mot de passe" name="cpass" value="<?php echo $_POST['cpass']; ?>" required>
			</div>

			<div class="input-group">
				<button name="submit" class="btn">Creer un compte</button>
			</div>

			<p class="login-register-text">Vou avez un compte ? <a href="seconnecter.php">Se connecter ici</a>.</p>
		
		</form>

	</div>

</body>
</html>