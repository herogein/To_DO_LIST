      
<?php      
        $servername = 'localhost';
        $username = 'root';
        $password = '';
        $base_name = "todolist";
   
        $conn = mysqli_connect($servername,$username,$password,$base_name);

        if (!$conn) 
            {die("Erreur : ".mysqli_connect_error());}
        else 
            {echo "connexion à todolist réussit <br>";}
    
        $table_name = "CREATE TABLE utilisateur (
                Id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, 
                Nom VARCHAR(30) NOT NULL, 
                Prenom VARCHAR(30) NOT NULL, 
                Email VARCHAR(70) NOT NULL, 
                Tel VARCHAR(50) NOT NULL, 
                Pass VARCHAR(30) NOT NULL,
                Cpass VARCHAR(30) NOT NULL)";
    
        if (mysqli_query($conn,$table_name)) 
            {echo "table utilisateur crée en succés";}
        else 
            {"Erreur lors de la création de la table : ".mysqli_error($conn);}
        
        mysqli_close($conn);

?>